x=[1:10]   %row matrix input
k=[1 2 3 4 5 6 7 8]
y=[2;3;4]    %column matrix input

a=[1 2 pi; 3 4 5; 4 5 8]   % 3*3 matrix

size(a)     % size calculation

b=a*2    %element multiplication

b(1,3)   %searching element

b(1,3)=10  %value change
