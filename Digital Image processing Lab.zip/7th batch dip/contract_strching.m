image=imread('3.jpg');
subplot(1,2,1);
imshow(image);
title('Original Image');

[x, y] = size(image);

for i = 1: x
    for j = 1: y
        if image(i, j) < 100
            image(i, j) = image(i, j) - 40;
           
        else
            image(i, j) = image(i, j) + 40;
           
        end
    end
end

subplot(1,2,2);
imshow(image);
title('Contrast Stretching Image');