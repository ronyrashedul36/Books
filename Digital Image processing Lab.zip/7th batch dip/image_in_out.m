image=imread('2.jpg');
imshow(image)