image = imread('p.jpg');
subplot(2,2,1),imshow(image),title('source image')
n=rgb2gray(image);
[x,y] = size(n);
for i=1: x
    for j=1:y
      if(i==j)
            n(i,j)=255;
       
        
      elseif (i+j ==y+1)
                n(i,j)=255;
      end
    end
end

 
subplot(2,2,2),imshow(n),title('after marking')