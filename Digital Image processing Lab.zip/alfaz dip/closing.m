x=imread('n.jpg');
im=x;
x=im2bw(im);
SE=strel('disk',10);
closeBW=imclose(x,SE);
imshow(closeBW);
title('closing');