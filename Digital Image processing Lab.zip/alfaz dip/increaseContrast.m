image= imread('C:\Users\Md Rashedul Islam\OneDrive\Desktop\cat.jpg');
i=rgb2gray(image);
figure;
subplot(1,2,1);imshow(i); 
subplot(1,2,2);imhist(i);


imh=imadjust(i,[0.5,0.9],[0.2,1.0]);
imh1=histeq(i);

figure;
subplot(2,2,1); imshow(imh);title('streched'); 
subplot(2,2,2); imhist(imh);
subplot(2,2,3); imshow(imh1);title('hist eq'); 
subplot(2,2,4); imhist(imh1); 
