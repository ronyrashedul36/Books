x=imread('n.jpg');
im=x;
x=im2bw(im);
SE=[0 1 0;1 1 1;0 1 0];
im2=imopen(x,SE);
imshow(im2);
title('opening');