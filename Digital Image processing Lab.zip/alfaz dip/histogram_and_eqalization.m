image=imread('pass 3.jpg');
imshow(image);
%color pic ke gray korar jonno
j=rgb2gray(image);
imshow(j);
%for histogram
figure;subplot(1,2,1);imshow(j);subplot(1,2,2);imhist(j);
%for histogram equalizaation
k=histeq(j);
figure;subplot(1,2,1);imshow(k);subplot(1,2,2);imhist(k);
