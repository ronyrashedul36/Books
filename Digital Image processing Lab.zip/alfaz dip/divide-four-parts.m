img=imread('n.jpg');
[rows, columns, dim] =size(img);

col1= 1;
col2=floor(columns/2);
col3 = col2+1;
row1=1;
row2= floor(rows/2);
row3=row2+1;

%new crop
upperLeft=imcrop(img,[col1 row1 col2 row2]);
upperRight=imcrop(img,[col3 row1 columns - col2 row2]);
lowerLeft=imcrop(img,[col1 row3 col2 row2]);
lowerRight=imcrop(img,[col3 row3 columns - col2 rows - row2]);


%display the image
subplot(2,3,2);
imshow(upperLeft);
subplot(2,3,3);
imshow(upperRight);
subplot(2,3,5);
imshow(lowerLeft);
subplot(2,3,6);
imshow(lowerRight);