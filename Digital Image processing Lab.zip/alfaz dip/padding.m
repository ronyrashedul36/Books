image = imread('C:\Users\Md Rashedul Islam\OneDrive\Desktop\cat.jpg');
figure,imshow(image),title('source image')
n=rgb2gray(image);
[x,y] = size(n);
for i=1: x
    for j=1:y
        if(i==2 ||j==2 ||i==x-1||j==y-1)
            n(i,j)=255;
        end
        if(i==3 ||j==3 ||i==x-2||j==y-2)
            n(i,j)=255;
        end
    if(i==4 ||j==4 ||i==x-3||j==y-3)
            n(i,j)=255;
    end
    end
end
 
figure,imshow(n),title('after padding')