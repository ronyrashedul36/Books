i=imread('x.jpg');
j=imread('y.jpg');

k=imresize(j,[size(i,1) size(i,2)]);

l=imadd(i,k);
m=imsubtract(i,k);


subplot(2,2,1),imshow(i),title('Orginal image');
subplot(2,2,2),imshow(j),title('Original 2 Image');
subplot(2,2,3),imshow(l),title('addition Image');
subplot(2,2,4),imshow(m),title('subtraction Image');
