image=imread('n.jpg');

image_multiplication=immultiply(image,1.5);
image_division=imdivide(image,4);

subplot(2,2,1),imshow(image),title('Orginal image');
subplot(2,2,2),imshow(image_multiplication),title('Multiplied Image');
subplot(2,2,3),imshow(image_division),title('Divided Image');
