img = imread('football.jpg');

[x y z] =size(img);
subplot(1,2,1),imshow(img),title('original image');
for i=1:x
    for j=1:y
        if(i==2 || j==2 || i==x-1 || j==y-1)
            img(i,j) = 255;
        end
    end
end


subplot(1,2,2),imshow(img),title('padding image');