
a=imread('football.jpg');

[x,y]=size(a);

 for i=1:x   
    for j=1:y 
        if i==j
            a(i,j)=0;
        else if (i+j==y+1)
            a(i,j)=0;
            end
        end
    end
 end
subplot(2,2,1),imshow(a),title('Orginal Image');
